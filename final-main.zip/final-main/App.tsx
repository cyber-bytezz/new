
import React, { useState } from 'react';
import { Header } from './components/ui/Header';
import Hero from './components/Hero';
import Process from './components/Process';
import Metrics from './components/Metrics';
import AIInsights from './components/AIInsights';
import Trends from './components/Trends';
import Privacy from './components/Privacy';
import Enterprise from './components/Enterprise';
import Footer from './components/Footer';
import AuthWorkflow from './components/AuthWorkflow';
import ProfilePrivacy from './components/ProfilePrivacy';
import AdminDashboard from './components/AdminDashboard';
import ArchitecturalStack from './components/ArchitecturalStack';

type ViewMode = 'landing' | 'portal' | 'privacy' | 'admin';

const App: React.FC = () => {
  const [viewMode, setViewMode] = useState<ViewMode>('landing');

  const enterPortal = () => setViewMode('portal');
  const enterPrivacy = () => setViewMode('privacy');
  const enterAdmin = () => setViewMode('admin');
  const exitToLanding = () => setViewMode('landing');

  return (
    <div className="min-h-screen bg-white selection:bg-blue-100 selection:text-blue-900 animate-reveal">
      <main>
        {viewMode === 'admin' ? (
          <AdminDashboard onClose={exitToLanding} />
        ) : viewMode === 'privacy' ? (
          <ProfilePrivacy onClose={exitToLanding} />
        ) : viewMode === 'portal' ? (
          <AuthWorkflow onClose={exitToLanding} onAdminLogin={enterAdmin} />
        ) : (
          <>
            <Header
              onSignInClick={enterPortal}
              onExitClick={exitToLanding}
              mode="landing"
            />
            <Hero onStartScan={enterPortal} />
            <Process />
            <Metrics />
            <ArchitecturalStack />

            <div className="py-0 bg-white flex justify-center">
              <div className="w-full max-w-7xl h-px bg-gradient-to-r from-transparent via-slate-100 to-transparent"></div>
            </div>

            <AIInsights />
            <Trends />
            <Privacy />
            <Enterprise />

            <section className="py-24 px-6 md:px-12 relative overflow-hidden bg-white">
              <div className="max-w-7xl mx-auto rounded-[4rem] bg-blue-600 p-12 md:p-24 relative overflow-hidden shadow-2xl shadow-blue-200">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-blue-400 to-blue-700"></div>
                <div className="absolute top-0 right-0 w-1/2 h-full bg-white/5 skew-x-12 translate-x-1/2"></div>

                <div className="relative z-10 max-w-3xl mx-auto text-center space-y-10">
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/10 text-white rounded-full text-[10px] font-black uppercase tracking-[0.3em] backdrop-blur-sm border border-white/20">
                    Join the Future of Care
                  </div>
                  <h2 className="text-4xl md:text-6xl font-extrabold text-white leading-tight tracking-tight">
                    Modernizing Wellness <br /> Synthesis, <span className="text-blue-100">Today.</span>
                  </h2>
                  <p className="text-lg text-blue-50 font-medium opacity-90 leading-relaxed max-w-2xl mx-auto">
                    Ready to experience the next standard in non-invasive healthcare diagnostics? Join over 1,200 partners globally.
                  </p>
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-6">
                    <button
                      onClick={enterPortal}
                      className="w-full sm:w-auto px-12 py-5 bg-white text-blue-600 rounded-2xl font-black text-sm shadow-2xl hover:bg-blue-50 transition-all transform hover:-translate-y-1"
                    >
                      Start Wellness Scan
                    </button>
                    <button
                      onClick={enterPrivacy}
                      className="w-full sm:w-auto px-12 py-5 border-2 border-white/30 text-white rounded-2xl font-black text-sm hover:bg-white/10 transition-all"
                    >
                      Privacy & Security
                    </button>
                  </div>
                </div>
              </div>
            </section>
            <Footer />
          </>
        )}
      </main>
    </div>
  );
};

export default App;
