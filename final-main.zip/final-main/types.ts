
export interface MetricData {
  label: string;
  value: number;
  unit?: string;
  status: 'good' | 'average' | 'optimal';
  color: string;
}

export interface Insight {
  id: string;
  title: string;
  description: string;
  type: 'energy' | 'stress' | 'habit';
}

export interface TrendData {
  day: string;
  energy: number;
  stress: number;
}
