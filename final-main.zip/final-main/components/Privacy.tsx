
import React from 'react';

const Privacy: React.FC = () => {
  return (
    <section id="privacy" className="py-24 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-20 items-center">
          <div className="lg:w-1/2 space-y-10">
            <div className="inline-flex items-center px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full text-[10px] font-black uppercase tracking-widest border border-blue-100">
              HIPAA & GDPR Compliant
            </div>
            <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 leading-tight">
              Patient Data <br />
              Safety is our <br />
              <span className="text-blue-600">Top Priority.</span>
            </h2>
            <p className="text-lg text-slate-500 leading-relaxed font-light max-w-md">
              BioMirror architecture is built on medical-grade security principles. We ensure your physiological signals remain yours.
            </p>

            <div className="grid gap-5">
              {[
                'On-device processing for raw imagery.',
                'Encrypted biometric flux storage.',
                'Instant data purging capabilities.'
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-4 group">
                  <div className="w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center text-white shrink-0 shadow-lg shadow-blue-100">
                    <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                  </div>
                  <span className="text-slate-700 font-semibold text-sm tracking-tight">{item}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:w-1/2 grid grid-cols-1 sm:grid-cols-2 gap-6 w-full">
            {[
              { title: 'Edge Encryption', desc: 'Secure data synthesis happens locally before cloud upload.', icon: '🛡️' },
              { title: 'No Data Resell', desc: 'Your medical insights are private. We never monetize personal data.', icon: '💎' },
              { title: 'Multi-Auth Sync', desc: 'Access your health history with secure multi-factor authentication.', icon: '🔐' },
              { title: 'Security Audits', desc: 'Regular third-party clinical and technical security reviews.', icon: '📝' }
            ].map((card, idx) => (
              <div key={idx} className="presentation-card p-8 group border-slate-100 shadow-sm hover:shadow-md">
                <div className="text-4xl mb-6 group-hover:scale-110 transition-transform">{card.icon}</div>
                <h4 className="text-slate-900 font-bold text-base mb-2 tracking-tight">{card.title}</h4>
                <p className="text-slate-500 text-xs leading-relaxed font-medium">{card.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Privacy;
