
import React from 'react';

const Enterprise: React.FC = () => {
  return (
    <section id="enterprise" className="py-24 px-6 md:px-12 bg-slate-50">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1 relative">
            <div className="rounded-[4rem] overflow-hidden shadow-2xl border-[16px] border-white relative group">
              <img
                src="/corporate-impact.png"
                alt="Modern corporate facility"
                className="w-full h-[600px] object-cover transition-transform duration-[8s] group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent"></div>

              <div className="absolute bottom-10 left-10 right-10">
                <div className="glass-ui p-8 rounded-[3rem] border border-white/50 shadow-2xl">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-2.5 h-2.5 bg-blue-600 rounded-full animate-pulse"></div>
                    <div className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Global Network Active</div>
                  </div>
                  <div className="text-lg font-bold text-slate-900 leading-tight">Empowering clinics with hospital-grade AI infrastructure.</div>
                </div>
              </div>
            </div>
          </div>

          <div className="order-1 lg:order-2 space-y-12">
            <div className="space-y-6">
              <h2 className="text-xs font-bold text-blue-600 uppercase tracking-widest">Clinic Solutions</h2>
              <p className="text-4xl md:text-5xl font-extrabold text-slate-900 leading-tight">Scalable Diagnostic Infrastructure</p>
              <p className="text-lg text-slate-500 font-light leading-relaxed">
                Seamlessly integrate BioMirror into your existing clinical workflow. High reliability, zero-friction patient onboarding.
              </p>
            </div>

            <div className="grid gap-4">
              {[
                { title: 'Electronic Health Sync', desc: 'Native HL7 and FHIR integration for medical records.', icon: '🏥' },
                { title: 'Provider Dashboard', desc: 'Centralized patient monitoring for medical teams.', icon: '📊' },
                { title: 'Enterprise Security', desc: 'Single Sign-On (SSO) and multi-layered clinical access.', icon: '🛡️' }
              ].map((item, idx) => (
                <div key={idx} className="presentation-card p-6 flex gap-6 items-center shadow-sm">
                  <div className="text-4xl shrink-0">{item.icon}</div>
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900 mb-0.5 tracking-tight">{item.title}</h3>
                    <p className="text-slate-500 font-medium text-xs">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4">
              <button className="flex items-center gap-6 group">
                <span className="text-base font-black text-slate-900 group-hover:text-blue-600 transition-colors">Request Partner Kit</span>
                <div className="w-12 h-12 rounded-full bg-slate-900 text-white flex items-center justify-center group-hover:bg-blue-600 transition-all transform group-hover:translate-x-3 shadow-xl">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7-7 7" /></svg>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Enterprise;
