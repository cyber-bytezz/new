
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white pt-24 pb-12 px-6 md:px-12 border-t border-slate-100">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-12 mb-20">
          <div className="col-span-2 space-y-6">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <div className="w-3.5 h-3.5 bg-white rounded-full"></div>
              </div>
              <span className="text-xl font-extrabold tracking-tight text-slate-900">BioMirror</span>
            </div>
            <p className="text-slate-500 text-sm max-w-xs leading-relaxed font-medium">
              Transforming patient outcomes through accessible, non-invasive diagnostic AI.
            </p>
          </div>

          <div>
            <h5 className="font-bold text-slate-900 mb-6 text-[10px] uppercase tracking-widest">Solutions</h5>
            <ul className="space-y-4 text-xs text-slate-500 font-semibold">
              <li><a href="#" className="hover:text-blue-600">Patient Dashboard</a></li>
              <li><a href="#" className="hover:text-blue-600">Clinic Portal</a></li>
              <li><a href="#" className="hover:text-blue-600">Enterprise API</a></li>
              <li><a href="#" className="hover:text-blue-600">Research Tools</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-slate-900 mb-6 text-[10px] uppercase tracking-widest">Trust & Legal</h5>
            <ul className="space-y-4 text-xs text-slate-500 font-semibold">
              <li><a href="#" className="hover:text-blue-600">HIPAA Compliance</a></li>
              <li><a href="#" className="hover:text-blue-600">GDPR Center</a></li>
              <li><a href="#" className="hover:text-blue-600">Security Whitepaper</a></li>
              <li><a href="#" className="hover:text-blue-600">AI Ethics</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-slate-900 mb-6 text-[10px] uppercase tracking-widest">Resources</h5>
            <ul className="space-y-4 text-xs text-slate-500 font-semibold">
              <li><a href="#" className="hover:text-blue-600">Case Studies</a></li>
              <li><a href="#" className="hover:text-blue-600">Clinical Data</a></li>
              <li><a href="#" className="hover:text-blue-600">Knowledge Hub</a></li>
              <li><a href="#" className="hover:text-blue-600">Status</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-slate-900 mb-6 text-[10px] uppercase tracking-widest">Contact</h5>
            <ul className="space-y-4 text-xs text-slate-500 font-semibold">
              <li><a href="#" className="hover:text-blue-600">Support</a></li>
              <li><a href="#" className="hover:text-blue-600">Sales</a></li>
              <li><a href="#" className="hover:text-blue-600">Locations</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-100 pt-12 flex flex-col md:flex-row justify-between gap-8 items-center">
          <p className="text-[11px] text-slate-400 font-bold">© 2024 BioMirror Healthcare Technologies. All rights reserved.</p>
          <div className="flex space-x-8 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
            <a href="#" className="hover:text-blue-600 transition">Privacy</a>
            <a href="#" className="hover:text-blue-600 transition">Terms</a>
            <a href="#" className="hover:text-blue-600 transition">Cookie Settings</a>
          </div>
        </div>

        <div className="mt-12 p-8 bg-blue-50/50 rounded-[2.5rem] border border-blue-100/50">
          <p className="text-[9px] text-blue-600 uppercase font-black tracking-[0.3em] mb-4">Clinical Disclaimer</p>
          <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
            BioMirror is a wellness and supportive diagnostic tool. It is intended to augment clinical decision-making by providing additional physiological data points. It should not be used as a standalone diagnostic tool. Always consult with a qualified medical professional for definitive diagnosis and treatment planning.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
