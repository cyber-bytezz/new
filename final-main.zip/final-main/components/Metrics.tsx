
import React from 'react';
import { METRICS } from '../constants';

const Metrics: React.FC = () => {
  return (
    <section id="metrics" className="pt-12 pb-32 px-6 md:px-12 bg-slate-50/40">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end gap-10 mb-24">
          <div className="space-y-4">
            <h2 className="text-xs font-black text-blue-600 uppercase tracking-[0.4em]">Live Telemetry</h2>
            <h3 className="text-5xl font-extrabold text-slate-900 tracking-tight">Patient Success Metrics</h3>
          </div>
          <p className="text-slate-500 text-sm font-bold max-w-xs leading-relaxed opacity-70">
            Aggregate data representing real-time diagnostic performance across our global provider network.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {METRICS.map((metric, idx) => (
            <div key={idx} className="presentation-card p-12 bg-white group hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.08)]">
              <div className="flex justify-between items-start mb-14">
                <div className="w-16 h-16 bg-blue-50/50 rounded-2xl flex items-center justify-center shadow-inner group-hover:bg-blue-600 transition-colors duration-500">
                  <div className={`w-3.5 h-3.5 rounded-full ${metric.color.replace('bg-', 'bg-')} group-hover:bg-white`}></div>
                </div>
                <div className="px-5 py-2 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{metric.status}</span>
                </div>
              </div>

              <div className="space-y-3 mb-10">
                <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em]">{metric.label}</h4>
                <div className="flex items-baseline gap-2">
                  <span className="text-7xl font-black text-slate-900 tracking-tighter group-hover:text-blue-600 transition-colors duration-500">{metric.value}</span>
                  <span className="text-3xl font-extrabold text-slate-200">{metric.unit}</span>
                </div>
              </div>

              <div className="h-3 bg-slate-50 rounded-full overflow-hidden border border-slate-100/50">
                <div
                  className="h-full bg-blue-600 transition-all duration-[2.5s] ease-out shadow-[0_0_15px_rgba(37,99,235,0.3)]"
                  style={{ width: `${metric.value}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Metrics;
