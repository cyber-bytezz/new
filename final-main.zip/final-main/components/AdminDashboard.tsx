
import React, { useState } from 'react';
import { Header } from './ui/Header';

interface User {
    id: string;
    name: string;
    email: string;
    status: 'active' | 'inactive' | 'pending';
    lastScan: string;
}

const AdminDashboard: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const [users, setUsers] = useState<User[]>([
        { id: '1', name: 'John Doe', email: 'john@example.com', status: 'active', lastScan: '2026-02-04' },
        { id: '2', name: 'Jane Smith', email: 'jane@example.com', status: 'pending', lastScan: 'N/A' },
        { id: '3', name: 'Robert Wilson', email: 'robert@clinical.com', status: 'inactive', lastScan: '2026-01-15' },
        { id: '4', name: 'Sarah Parker', email: 'sarah@med.org', status: 'pending', lastScan: 'N/A' },
    ]);

    const stats = {
        total: users.length,
        active: users.filter(u => u.status === 'active').length,
        pending: users.filter(u => u.status === 'pending').length,
        scans: 1240
    };

    const toggleStatus = (id: string) => {
        setUsers(users.map(u => {
            if (u.id === id) {
                return { ...u, status: u.status === 'active' ? 'inactive' : 'active' };
            }
            return u;
        }));
    };

    const handleApproval = (id: string, accept: boolean) => {
        setUsers(users.map(u => {
            if (u.id === id) {
                return { ...u, status: accept ? 'active' : 'inactive' };
            }
            return u;
        }));
    };

    return (
        <div className="min-h-screen bg-[#F8FAFC]">
            <Header mode="portal" onExitClick={onClose} />

            <main className="max-w-7xl mx-auto px-6 py-12 space-y-12">
                <div className="flex justify-between items-end">
                    <div className="space-y-4">
                        <h1 className="text-5xl font-black text-slate-900 tracking-tighter">Admin Control</h1>
                        <p className="text-lg text-slate-500 font-medium tracking-tight uppercase tracking-widest text-[10px]">Operations & User Management</p>
                    </div>
                    <div className="flex gap-4">
                        <div className="px-6 py-4 bg-white border border-slate-100 rounded-3xl shadow-sm">
                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">System Load</p>
                            <div className="flex items-center gap-2">
                                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                                <span className="text-sm font-bold text-slate-900">Optimal (12%)</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Stats Grid */}
                <div className="grid md:grid-cols-4 gap-6">
                    {[
                        { label: 'Total Users', value: stats.total, color: 'text-blue-600', icon: '👥' },
                        { label: 'Active Sessions', value: stats.active, color: 'text-emerald-600', icon: '⚡' },
                        { label: 'Pending Approval', value: stats.pending, color: 'text-amber-600', icon: '🕒' },
                        { label: 'Total Scans', value: stats.scans, color: 'text-slate-900', icon: '🧬' }
                    ].map((stat, i) => (
                        <div key={i} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all group">
                            <div className="text-3xl mb-4 group-hover:scale-110 transition-transform">{stat.icon}</div>
                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">{stat.label}</p>
                            <p className={`text-4xl font-black ${stat.color} tracking-tighter`}>{stat.value}</p>
                        </div>
                    ))}
                </div>

                {/* User Table */}
                <div className="bg-white rounded-[3rem] border border-slate-100 shadow-2xl overflow-hidden">
                    <div className="p-10 border-b border-slate-50 flex justify-between items-center">
                        <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">User Directory</h3>
                        <div className="flex gap-2">
                            <button className="px-4 py-2 bg-slate-50 text-slate-400 rounded-xl text-[10px] font-black uppercase">All</button>
                            <button className="px-4 py-2 text-slate-400 rounded-xl text-[10px] font-black uppercase">Pending</button>
                        </div>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead>
                                <tr className="bg-slate-50/50">
                                    <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-[9px]">User Identity</th>
                                    <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-[9px]">Status</th>
                                    <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-[9px]">Last Scan</th>
                                    <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-[9px] text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50">
                                {users.map((user) => (
                                    <tr key={user.id} className="hover:bg-slate-50/50 transition-colors group">
                                        <td className="px-10 py-8">
                                            <div className="flex items-center gap-4">
                                                <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-black">
                                                    {user.name.charAt(0)}
                                                </div>
                                                <div>
                                                    <p className="font-black text-slate-900 leading-none mb-1">{user.name}</p>
                                                    <p className="text-xs text-slate-400 font-medium">{user.email}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-10 py-8">
                                            <div className={`inline-flex items-center px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${user.status === 'active' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                                                    user.status === 'pending' ? 'bg-amber-50 text-amber-600 border border-amber-100' :
                                                        'bg-slate-100 text-slate-400 border border-slate-200'
                                                }`}>
                                                {user.status}
                                            </div>
                                        </td>
                                        <td className="px-10 py-8 text-sm font-bold text-slate-500">{user.lastScan}</td>
                                        <td className="px-10 py-8 text-right">
                                            {user.status === 'pending' ? (
                                                <div className="flex justify-end gap-2">
                                                    <button
                                                        onClick={() => handleApproval(user.id, true)}
                                                        className="px-6 py-2.5 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-100 hover:bg-emerald-700"
                                                    >
                                                        Accept
                                                    </button>
                                                    <button
                                                        onClick={() => handleApproval(user.id, false)}
                                                        className="px-6 py-2.5 bg-white border border-slate-200 text-slate-400 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-50"
                                                    >
                                                        Reject
                                                    </button>
                                                </div>
                                            ) : (
                                                <button
                                                    onClick={() => toggleStatus(user.id)}
                                                    className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${user.status === 'active' ? 'bg-slate-100 text-slate-600 hover:bg-red-50 hover:text-red-500' : 'bg-blue-600 text-white'
                                                        }`}
                                                >
                                                    {user.status === 'active' ? 'Deactivate' : 'Activate'}
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default AdminDashboard;
