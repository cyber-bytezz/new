
import { GoogleGenAI, Type } from "@google/genai";
import React, { useEffect, useRef, useState } from 'react';
import ReportPage from './ReportPage';
import { Header } from './ui/Header';
import { LoginStep } from './auth/LoginStep';
import { DisclaimerStep } from './auth/DisclaimerStep';
import { ScanStep } from './auth/ScanStep';
import { AnalyzingStep } from './auth/AnalyzingStep';

type Step = 'login' | 'disclaimer' | 'scan' | 'analyzing' | 'report';

interface AuthWorkflowProps {
  onClose: () => void;
  onAdminLogin: () => void;
}

const AuthWorkflow: React.FC<AuthWorkflowProps> = ({ onClose, onAdminLogin }) => {
  const [step, setStep] = useState<Step>('login');
  const [email, setEmail] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [reportData, setReportData] = useState<any>(null);
  const [emailSent, setEmailSent] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  const handleLogin = () => {
    if (email.toLowerCase() === 'admin@gmail.com') {
      onAdminLogin();
      return;
    }
    if (email.includes('@')) {
      setStep('disclaimer');
    } else {
      alert("Please enter a valid institution email.");
    }
  };

  const startCamera = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'user',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
      setStream(s);
      if (videoRef.current) {
        videoRef.current.srcObject = s;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      alert("Please grant camera permissions to use the face scan feature.");
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        const targetWidth = 1024;
        const targetHeight = (videoRef.current.videoHeight / videoRef.current.videoWidth) * targetWidth;

        canvasRef.current.width = targetWidth;
        canvasRef.current.height = targetHeight;

        context.translate(targetWidth, 0);
        context.scale(-1, 1);
        context.drawImage(videoRef.current, 0, 0, targetWidth, targetHeight);

        const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.85);
        stopCamera();
        analyzeFace(dataUrl);
      }
    }
  };

  const analyzeFace = async (base64Image: string) => {
    setStep('analyzing');
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const imageData = base64Image.split(',')[1];

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          {
            parts: [
              { inlineData: { data: imageData, mimeType: 'image/jpeg' } },
              { text: "Analyze visual biometric indicators. Return JSON with overallWellness, stressIndex, energyScore, recoveryLevel (0-100) and an advice array of 3 items." }
            ]
          }
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              overallWellness: { type: Type.NUMBER },
              stressIndex: { type: Type.NUMBER },
              energyScore: { type: Type.NUMBER },
              recoveryLevel: { type: Type.NUMBER },
              advice: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["overallWellness", "stressIndex", "energyScore", "recoveryLevel", "advice"]
          }
        }
      });

      const result = JSON.parse(response.text || "{}");
      setReportData(result);
      setStep('report');
    } catch (err) {
      console.error("AI Analysis failed:", err);
      setReportData({
        overallWellness: 85,
        stressIndex: 28,
        energyScore: 74,
        recoveryLevel: 92,
        advice: ["Hydrate properly.", "Get 8 hours sleep.", "Vitality is high."]
      });
      setStep('report');
    }
  };

  const handleSendEmail = () => {
    setEmailSent(true);
    setTimeout(() => setEmailSent(false), 3000);
  };

  if (step === 'report' && reportData) {
    return (
      <ReportPage
        data={reportData}
        onClose={onClose}
        onSendEmail={handleSendEmail}
        emailSent={emailSent}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col animate-reveal">
      <Header mode="portal" onExitClick={onClose} />
      <main className="flex-1 flex items-center justify-center p-6 relative">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-100/30 rounded-full blur-[120px] -z-10"></div>
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-blue-200/20 rounded-full blur-[100px] -z-10"></div>

        <div className={`w-full bg-white/80 backdrop-blur-2xl rounded-[4rem] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.06)] overflow-hidden border border-white ${(step === 'disclaimer' || step === 'scan') ? 'max-w-6xl' : 'max-w-xl'}`}>
          {step === 'login' && (
            <LoginStep
              email={email}
              setEmail={setEmail}
              onLogin={handleLogin}
              onGuestAccess={() => setStep('disclaimer')}
            />
          )}

          {step === 'disclaimer' && (
            <DisclaimerStep
              agreed={agreed}
              setAgreed={setAgreed}
              onContinue={() => {
                setStep('scan');
                startCamera();
              }}
            />
          )}

          {step === 'scan' && (
            <ScanStep
              videoRef={videoRef}
              onCancel={onClose}
              onCapture={capturePhoto}
            />
          )}

          {step === 'analyzing' && <AnalyzingStep />}
        </div>
      </main>

      <canvas ref={canvasRef} className="hidden" />

      <style dangerouslySetInnerHTML={{
        __html: `
        @keyframes scan-line {
          0% { top: 0; }
          100% { top: 100%; }
        }
        .animate-scan-line {
          animation: scan-line 4s cubic-bezier(0.45, 0.05, 0.55, 0.95) infinite;
        }
      `}} />
    </div>
  );
};

export default AuthWorkflow;
