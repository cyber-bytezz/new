
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TREND_DATA } from '../constants';

interface TrendMetric {
  label: string;
  value: string;
  trend: 'up' | 'down' | 'stable';
  color: string;
}

const Trends: React.FC = () => {
  const metrics: TrendMetric[] = [
    { label: 'Avg Wellness', value: '78/100', trend: 'up', color: 'text-emerald-500' },
    { label: 'Weekly Stress', value: '24%', trend: 'down', color: 'text-blue-500' },
    { label: 'Recovery Rate', value: '92%', trend: 'up', color: 'text-blue-600' }
  ];

  return (
    <section id="trends" className="pt-12 pb-24 px-6 md:px-12 bg-slate-50">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="flex flex-col md:flex-row justify-between items-end gap-6 text-center md:text-left">
          <div className="space-y-4">
            <div className="inline-flex items-center px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full text-[10px] font-black uppercase tracking-widest border border-blue-100 mx-auto md:mx-0">
              Performance Tracking
            </div>
            <h2 className="text-5xl md:text-6xl font-black text-slate-900 tracking-tighter leading-none">
              Weekly Health <br /> <span className="text-blue-600">Dynamics.</span>
            </h2>
          </div>
          <div className="flex items-center gap-4 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm">
            <button className="px-6 py-2.5 bg-slate-900 text-white shadow-xl rounded-xl text-xs font-black uppercase tracking-widest">Wellness</button>
            <button className="px-6 py-2.5 text-xs font-black text-slate-400 uppercase tracking-widest hover:text-slate-600">Stress</button>
            <button className="px-6 py-2.5 text-xs font-black text-slate-400 uppercase tracking-widest hover:text-slate-600">Sleep</button>
          </div>
        </div>

        <div className="grid lg:grid-cols-12 gap-12">
          {/* Main Chart */}
          <div className="lg:col-span-8 bg-white rounded-[4rem] p-12 shadow-[0_40px_80px_-20px_rgba(0,0,0,0.05)] border border-slate-100 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-1/3 h-full bg-blue-50/30 -skew-x-12 translate-x-1/2"></div>

            <div className="relative z-10 flex flex-col space-y-12">
              <div className="flex flex-wrap gap-12">
                {metrics.map((m, i) => (
                  <div key={i} className="space-y-1">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">{m.label}</span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-black text-slate-900 tracking-tighter">{m.value}</span>
                      <span className={`text-[10px] font-bold ${m.color}`}>
                        {m.trend === 'up' ? '↗' : '↘'} 4.2%
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="h-[350px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={TREND_DATA}>
                    <defs>
                      <linearGradient id="colorWellness" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#2563eb" stopOpacity={0.15} />
                        <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis
                      dataKey="day"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: '#94a3b8', fontSize: 11, fontWeight: 700 }}
                      dy={15}
                    />
                    <YAxis hide domain={[0, 100]} />
                    <Tooltip
                      contentStyle={{
                        borderRadius: '24px',
                        border: '1px solid #f1f5f9',
                        backgroundColor: '#ffffff',
                        boxShadow: '0 30px 60px -15px rgba(0,0,0,0.1)',
                        padding: '16px 20px',
                        fontWeight: 800
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="energy"
                      stroke="#2563eb"
                      strokeWidth={6}
                      fillOpacity={1}
                      fill="url(#colorWellness)"
                      animationDuration={2500}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Badges & Achievements */}
          <div className="lg:col-span-4 space-y-8">
            <div className="bg-slate-900 rounded-[3.5rem] p-10 text-white shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-blue-600/20 blur-3xl"></div>
              <h4 className="text-xs font-black uppercase tracking-[0.3em] text-blue-400 mb-8">Improvement Badges</h4>
              <div className="space-y-6">
                {[
                  { title: 'Consistency King', desc: 'Scan everyday for 7 days', icon: '👑', progress: 100 },
                  { title: 'Stress Master', desc: 'Maintained low stress for 3 days', icon: '🧘', progress: 65 },
                  { title: 'Early Bird', desc: 'Scanned before 8 AM', icon: '☀️', progress: 30 }
                ].map((badge, i) => (
                  <div key={i} className="space-y-3">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center text-xl">{badge.icon}</div>
                      <div className="flex-1">
                        <p className="text-sm font-black tracking-tight">{badge.title}</p>
                        <p className="text-[10px] text-slate-400 font-medium">{badge.desc}</p>
                      </div>
                    </div>
                    <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-600 rounded-full" style={{ width: `${badge.progress}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
              <button className="w-full mt-10 py-4 bg-white text-slate-900 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-50 transition-colors">
                View All Achievements
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Trends;
