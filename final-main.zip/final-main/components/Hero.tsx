
import React from 'react';

interface HeroProps {
  onStartScan: () => void;
}

const Hero: React.FC<HeroProps> = ({ onStartScan }) => {
  return (
    <section className="relative pt-24 md:pt-16 pb-8 px-6 md:px-12 hero-gradient overflow-hidden">
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
        <div className="space-y-10 relative z-10 opacity-0 animate-reveal">
          <div className="inline-flex items-center gap-3 px-4 py-2 bg-white/50 backdrop-blur-md text-blue-700 rounded-full text-xs font-bold border border-blue-100 shadow-sm">
            <span className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></span>
            <span className="opacity-90 tracking-tight">Clinically Validated AI Technology</span>
          </div>

          <h1 className="text-6xl lg:text-[5.5rem] font-extrabold text-slate-900 leading-[0.95] tracking-tighter">
            BioMirror <br />
            <span className="text-blue-600">Wellness</span> Insights <br />
            in Seconds.
          </h1>

          <p className="text-xl text-slate-500 font-medium leading-relaxed max-w-xl">
            Track 30+ health markers through a face scan using any camera.
            Non-invasive AI wellness insights designed for the future of care.
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-8 pt-4">
            <button
              onClick={onStartScan}
              className="group px-10 py-6 bg-slate-900 text-white rounded-[2rem] font-black text-xl shadow-2xl hover:bg-blue-600 transition-all transform hover:-translate-y-1 flex items-center justify-between min-w-[280px] gap-6"
            >
              <span className="tracking-tight uppercase text-sm font-black tracking-[0.2em]">Start Wellness Scan</span>
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center group-hover:translate-x-1 transition-transform duration-300">
                <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
              </div>
            </button>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Privacy Assurance</span>
              <p className="text-[12px] text-slate-500 font-bold leading-relaxed max-w-[200px]">
                No medical diagnosis. <br />Wellness guidance only.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6 pt-6 grayscale opacity-40">
            <div className="text-[10px] font-black uppercase tracking-widest text-slate-400">Trusted By</div>
            <div className="h-6 w-px bg-slate-200"></div>
            <span className="font-bold text-slate-900">HealthFirst</span>
            <span className="font-bold text-slate-900">MediGuard</span>
            <span className="font-bold text-slate-900">VitalsIQ</span>
          </div>
        </div>

        <div className="relative opacity-0 animate-reveal delay-200">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-blue-400/5 rounded-full blur-[100px] -z-10"></div>

          <div className="relative rounded-[4rem] overflow-hidden shadow-[0_50px_100px_-20px_rgba(0,0,0,0.15)] border-[16px] border-white z-0">
            <img
              src="/hero-scan.png"
              alt="Bio-Mirror Face Scan"
              className="w-full h-[650px] object-cover scale-105 hover:scale-100 transition-transform duration-[2s]"
            />
            <div className="absolute inset-0 bg-gradient-to-tr from-blue-900/40 via-transparent to-transparent"></div>

            {/* Animated Scanning Overlay */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-96 border-2 border-white/30 rounded-[3rem] border-dashed animate-pulse-soft"></div>
              <div className="absolute top-0 left-0 right-0 h-1 bg-blue-400 shadow-[0_0_20px_rgba(37,99,235,0.8)] animate-scan-slow"></div>
            </div>
          </div>

          <div className="absolute -bottom-8 -left-12 glass-ui p-10 rounded-[3rem] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] border border-white/50 w-80 animate-float">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-black text-blue-600 uppercase tracking-[0.2em]">Signal Precision</span>
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-6xl font-black text-slate-900 tracking-tighter">100%</span>
              </div>
              <p className="text-[12px] text-slate-500 font-bold leading-relaxed">Local device processing. <br />Zero cloud dependency.</p>
              <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-600 w-full rounded-full shadow-[0_0_15px_rgba(37,99,235,0.4)]"></div>
              </div>
            </div>
          </div>

          <div className="absolute top-12 -right-8 glass-ui p-6 rounded-[2.5rem] shadow-2xl border border-white/50 w-64 hidden lg:block animate-float delay-300" style={{ animationDuration: '6s' }}>
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-blue-600 shadow-xl">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-black text-slate-900">Real-time Analysis</span>
                <span className="text-[10px] text-blue-500 font-bold uppercase tracking-widest">30+ Markers</span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="h-2 bg-slate-100 rounded-full w-full"></div>
              <div className="h-2 bg-slate-100 rounded-full w-5/6"></div>
              <div className="h-2 bg-slate-100 rounded-full w-4/6"></div>
            </div>
          </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{
        __html: `
        @keyframes scan-slow {
          0% { top: 10%; opacity: 0; }
          50% { opacity: 1; }
          100% { top: 90%; opacity: 0; }
        }
        .animate-scan-slow {
          animation: scan-slow 8s ease-in-out infinite;
        }
      `}} />
    </section>
  );
};

export default Hero;
