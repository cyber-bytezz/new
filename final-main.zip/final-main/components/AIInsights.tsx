
import React from 'react';
import { INSIGHTS } from '../constants';

const AIInsights: React.FC = () => {
  return (
    <section id="features" className="pt-12 pb-20 px-6 md:px-12 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12 space-y-4">
          <h2 className="text-xs font-black text-blue-600 uppercase tracking-[0.4em]">Core Architecture</h2>
          <h3 className="text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight">The BioMirror Total Care Model</h3>
          <p className="text-slate-500 text-xl max-w-2xl mx-auto font-medium leading-relaxed opacity-80">
            A harmonious integration of physiological data points and expert-level clinical oversight.
          </p>
        </div>

        <div className="relative">
          {/* Main Content Area */}
          <div className="rounded-[4rem] overflow-hidden shadow-[0_60px_120px_-30px_rgba(0,0,0,0.2)] relative h-[600px] mb-16 group">
            <img
              src="/rppg-sensing.png"
              alt="Medical oversight"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[5s]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>

            <div className="absolute bottom-16 left-16 right-16 flex flex-col md:flex-row items-end justify-between gap-10">
              <div className="text-white space-y-4 max-w-xl">
                <div className="px-4 py-1.5 bg-blue-600 rounded-full w-fit text-[10px] font-black uppercase tracking-widest shadow-lg">Clinical Expert Layer</div>
                <h4 className="text-3xl font-extrabold tracking-tight">Expert-Verified Diagnostic Analysis</h4>
                <p className="text-blue-100 text-base opacity-90 font-medium leading-relaxed">
                  Every digital signal processed by our proprietary Bio-Sync AI is verified against clinical standards by a network of over 1,200 board-certified specialists.
                </p>
              </div>
              <button className="px-10 py-5 bg-white text-blue-600 rounded-[1.5rem] font-black text-sm shadow-2xl hover:scale-105 transition-transform uppercase tracking-widest">
                Verify Framework
              </button>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-10">
            {INSIGHTS.map((insight) => (
              <div key={insight.id} className="presentation-card p-10 flex flex-col gap-8 group">
                <div className="w-20 h-20 bg-blue-50/50 rounded-[2.5rem] flex items-center justify-center text-4xl shadow-inner group-hover:bg-blue-600 group-hover:rotate-6 transition-all duration-500">
                  <span className="group-hover:scale-125 transition-transform">{insight.type === 'stress' ? '🩺' : insight.type === 'energy' ? '🔋' : '🌱'}</span>
                </div>
                <div className="space-y-3">
                  <h4 className="text-2xl font-extrabold text-slate-900 tracking-tight group-hover:text-blue-600 transition-colors">{insight.title}</h4>
                  <p className="text-sm text-slate-500 leading-relaxed font-semibold opacity-80">{insight.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIInsights;
