
import React from 'react';
import { Header } from './ui/Header';

interface ProfilePrivacyProps {
    onClose: () => void;
}

const ProfilePrivacy: React.FC<ProfilePrivacyProps> = ({ onClose }) => {
    return (
        <div className="min-h-screen bg-[#F8FAFC] animate-reveal pb-20">
            <Header mode="portal" onExitClick={onClose} />

            <main className="max-w-4xl mx-auto px-6 pt-16 space-y-12">
                <div className="space-y-4">
                    <h1 className="text-5xl font-black text-slate-900 tracking-tighter">Account & Privacy</h1>
                    <p className="text-lg text-slate-500 font-medium">Manage your biometric data and security preferences.</p>
                </div>

                <div className="grid gap-8">
                    {/* Data Control Section */}
                    <div className="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-sm space-y-8">
                        <div className="flex items-center justify-between">
                            <div className="space-y-1">
                                <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">Data Governance</h3>
                                <p className="text-sm text-slate-500 font-medium">Control how your physiology is processed.</p>
                            </div>
                            <div className="px-4 py-2 bg-emerald-50 text-emerald-600 rounded-xl text-[10px] font-black uppercase tracking-widest border border-emerald-100 flex items-center gap-2">
                                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                                Device Processing Active
                            </div>
                        </div>

                        <div className="grid gap-4">
                            {[
                                { title: 'Local Synthesis Mode', desc: 'Process all pixel data on your physical device hardware.', status: 'Enabled', active: true },
                                { title: 'Biometric Discard', desc: 'Auto-purge raw imagery instantly after matrix analysis.', status: 'Enabled', active: true },
                                { title: 'Hardware Sync', desc: 'Phase-2: Display Unit | Phase-3: Weight & Height Unit.', status: 'Upcoming', active: false }
                            ].map((item, i) => (
                                <div key={i} className="flex items-center justify-between p-6 rounded-3xl bg-slate-50 border border-slate-100 group hover:bg-white hover:border-blue-100 transition-all">
                                    <div className="space-y-1">
                                        <p className="font-black text-slate-900 text-sm uppercase tracking-tight">{item.title}</p>
                                        <p className="text-xs text-slate-500 font-medium">{item.desc}</p>
                                    </div>
                                    <div className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest ${item.active ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-400'}`}>
                                        {item.status}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Privacy & Legal Section */}
                    <div className="bg-slate-900 rounded-[3rem] p-10 text-white shadow-2xl space-y-8 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/10 blur-3xl"></div>

                        <div className="space-y-2 relative z-10">
                            <h3 className="text-xl font-black uppercase tracking-tight">Legal & Compliance</h3>
                            <p className="text-sm text-slate-400 font-medium opacity-80">BioMirror is non-clinical and for wellness ONLY.</p>
                        </div>

                        <div className="grid sm:grid-cols-2 gap-6 relative z-10">
                            {[
                                { title: 'Privacy Policy', icon: '📄' },
                                { title: 'Consent Settings', icon: '🤝' },
                                { title: 'Export Audit Log', icon: '📥' },
                                { title: 'Delete History', icon: '🗑️', danger: true }
                            ].map((item, i) => (
                                <button key={i} className={`flex items-center gap-6 p-6 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-left ${item.danger ? 'hover:border-red-500/50' : 'hover:border-blue-500/50'}`}>
                                    <div className="text-2xl">{item.icon}</div>
                                    <span className={`text-sm font-black uppercase tracking-widest ${item.danger ? 'text-red-400' : 'text-white'}`}>{item.title}</span>
                                </button>
                            ))}
                        </div>

                        <div className="p-8 bg-white/5 rounded-3xl border border-white/10 relative z-10">
                            <div className="flex items-start gap-6">
                                <div className="text-2xl">⚠️</div>
                                <div className="space-y-2">
                                    <h4 className="text-sm font-black uppercase tracking-widest text-blue-400">AI Disclaimer</h4>
                                    <p className="text-xs text-slate-300 leading-relaxed font-medium">
                                        BioMirror uses synthetic neural networks (GenAI) to interpret physiological metadata.
                                        It is NOT a medical device, is NOT FDA approved (yet), and should NOT be used for clinical diagnosis.
                                        Always consult with a professional.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="flex justify-center pt-8">
                    <button
                        onClick={onClose}
                        className="px-12 py-5 bg-slate-900 text-white rounded-2xl font-black text-sm uppercase tracking-[0.3em] shadow-2xl hover:bg-blue-600 transition-all"
                    >
                        Back to Dashboard
                    </button>
                </div>
            </main>
        </div>
    );
};

export default ProfilePrivacy;
