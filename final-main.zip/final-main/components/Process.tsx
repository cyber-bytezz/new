import React, { useState } from 'react';

const Process: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);

  const steps = [
    {
      title: 'Digital Diagnosis',
      desc: 'Precision signal extraction from high-fidelity visual streams.',
      image: '/hero-scan.png'
    },
    {
      title: 'Holistic Treatment',
      desc: 'Smarter care plans reviewed by verified medical experts.',
      image: '/medical-precision.png'
    },
    {
      title: 'Active Recovery',
      desc: 'Round-the-clock monitoring of vital wellness fluctuations.',
      image: '/rppg-sensing.png'
    },
    {
      title: 'Proactive Support',
      desc: 'Early-stage detection through continuous AI pattern matching.',
      image: '/clinical-safety.png'
    }
  ];

  return (
    <section id="methodology" className="pt-20 pb-12 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-20 items-center">
        <div className="lg:w-1/2 relative group">
          <div className="relative rounded-[3rem] overflow-hidden shadow-[0_40px_80px_-20px_rgba(0,0,0,0.1)] border-[12px] border-slate-50">
            <img
              src={steps[activeStep].image}
              alt={steps[activeStep].title}
              className="w-full h-[600px] object-cover transition-all duration-700 ease-in-out group-hover:scale-105"
            />
            {/* Overlay Gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-blue-900/20 to-transparent pointer-events-none"></div>
          </div>
          {/* Abstract graphic accent */}
          <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-blue-100/40 rounded-full blur-[80px] -z-10 animate-pulse-soft"></div>
        </div>

        <div className="lg:w-1/2 space-y-10">
          <div className="space-y-4">
            <div className="inline-flex items-center px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full text-[9px] font-black uppercase tracking-widest border border-blue-100">
              Patient Journey
            </div>
            <h3 className="text-4xl lg:text-5xl font-extrabold text-slate-900 leading-[1.1] tracking-tight">
              A Simplified Path to <br /> <span className="text-blue-600">Comprehensive Care</span>
            </h3>
            <p className="text-lg text-slate-500 font-medium leading-relaxed max-w-xl">
              BioMirror redefines the clinical experience through non-invasive synthesis of biological signals and expert oversight.
            </p>
          </div>

          <div className="grid gap-3">
            {steps.map((item, idx) => (
              <div
                key={idx}
                onMouseEnter={() => setActiveStep(idx)}
                className={`group flex items-center justify-between p-6 rounded-[2rem] transition-all duration-500 cursor-pointer border border-transparent ${activeStep === idx ? 'bg-blue-600 shadow-xl shadow-blue-100 border-blue-100' : 'hover:bg-slate-50'}`}
              >
                <div className="space-y-1">
                  <h4 className={`text-xl font-black tracking-tight transition-colors ${activeStep === idx ? 'text-white' : 'text-slate-900 group-hover:text-blue-600'}`}>
                    {item.title}
                  </h4>
                  <p className={`text-xs font-bold transition-colors ${activeStep === idx ? 'text-blue-100' : 'text-slate-500'}`}>
                    {item.desc}
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-500 ${activeStep === idx ? 'bg-white text-blue-600 rotate-90 scale-105' : 'bg-slate-50 text-slate-400 group-hover:bg-blue-100 group-hover:text-blue-600 group-hover:rotate-45'}`}>
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7-7 7" /></svg>
                </div>
              </div>
            ))}
          </div>

          <button className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs hover:bg-blue-600 transition-all shadow-xl hover:shadow-blue-50 uppercase tracking-[0.2em]">
            Service Directory
          </button>
        </div>
      </div>
    </section>
  );
};

export default Process;
