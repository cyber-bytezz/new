
import React from 'react';
import { Header } from './ui/Header';
import { Button } from './ui/button';

interface ReportPageProps {
  data: {
    overallWellness: number;
    stressIndex: number;
    energyScore: number;
    recoveryLevel: number;
    heartRate?: number;
    fatigueProbability?: number;
    skinVitality?: number;
    circulationQuality?: number;
    advice: string[];
  };
  onClose: () => void;
  onSendEmail: () => void;
  emailSent: boolean;
}

const ReportPage: React.FC<ReportPageProps> = ({ data, onClose, onSendEmail, emailSent }) => {
  const timestamp = new Date().toLocaleString('en-US', {
    dateStyle: 'full',
    timeStyle: 'short'
  });
  const reportId = `BIO-${Math.floor(100000 + Math.random() * 900000)}`;

  // Ensure mock values for new fields if not provided by AI
  const heartRate = data.heartRate || 72;
  const fatigueProb = data.fatigueProbability || 15;
  const skinVitality = data.skinVitality || 88;
  const circulation = data.circulationQuality || 94;

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-500';
    if (score >= 60) return 'text-blue-500';
    if (score >= 40) return 'text-amber-500';
    return 'text-orange-500'; // Avoid red as requested
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] animate-reveal pb-20">
      <Header
        mode="report"
        onExitClick={onClose}
        customActions={
          <div className="flex gap-4">
            <Button
              onClick={() => window.print()}
              className="rounded-xl text-[10px] font-black uppercase tracking-widest bg-white text-slate-900 border border-slate-200 hover:bg-slate-50"
            >
              Export PDF
            </Button>
            <Button
              onClick={onSendEmail}
              className={cn(
                "rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                emailSent ? 'bg-emerald-500 text-white' : 'bg-slate-900 text-white hover:bg-blue-600'
              )}
            >
              {emailSent ? 'Sent to EHR' : 'Share Report'}
            </Button>
          </div>
        }
      />

      <div className="max-w-7xl mx-auto px-6 pt-12">
        {/* Top Section: Summary */}
        <div className="grid lg:grid-cols-12 gap-12 mb-16">
          <div className="lg:col-span-4">
            <div className="bg-white rounded-[4rem] p-12 shadow-[0_40px_80px_-20px_rgba(0,0,0,0.05)] border border-slate-100 relative overflow-hidden h-full flex flex-col items-center justify-center">
              <div className="absolute top-0 left-0 w-full h-2 bg-blue-600"></div>
              <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-8 text-center">Wellness Today</p>

              <div className="relative flex items-center justify-center mb-6">
                <svg className="w-56 h-56 transform -rotate-90">
                  <circle cx="112" cy="112" r="100" stroke="currentColor" strokeWidth="16" fill="transparent" className="text-slate-50" />
                  <circle
                    cx="112" cy="112" r="100" stroke="currentColor" strokeWidth="16" fill="transparent"
                    strokeDasharray={2 * Math.PI * 100}
                    strokeDashoffset={2 * Math.PI * 100 * (1 - data.overallWellness / 100)}
                    strokeLinecap="round"
                    className={`${getScoreColor(data.overallWellness)} transition-all duration-[2.5s] ease-out`}
                  />
                </svg>
                <div className="absolute flex flex-col items-center">
                  <span className="text-7xl font-black text-slate-900 tracking-tighter">{data.overallWellness}</span>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">/ 100</span>
                </div>
              </div>
              <div className="px-6 py-2 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase tracking-widest">
                Optimal Condition
              </div>
            </div>
          </div>

          <div className="lg:col-span-8 flex flex-col justify-center">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-600 rounded-md text-[10px] font-black uppercase tracking-widest border border-blue-100 w-fit">
                Session ID: {reportId}
              </div>
              <h1 className="text-5xl md:text-7xl font-black text-slate-900 tracking-tighter leading-none">
                Your Biometric <br />
                <span className="text-blue-600">Synthesis.</span>
              </h1>
              <p className="text-xl text-slate-500 font-medium max-w-2xl">
                AI-driven insights based on 30s rPPG camera analysis. These markers reflect your current physiological state.
              </p>
              <div className="flex gap-8 pt-4">
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Last Scan</span>
                  <span className="text-sm font-bold text-slate-900">{timestamp}</span>
                </div>
                <div className="w-px h-10 bg-slate-200"></div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Device</span>
                  <span className="text-sm font-bold text-slate-900">BioMirror v1.2</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Vital Signals */}
          <div className="space-y-8">
            <h3 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-4">
              <span className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center text-sm">V</span>
              Vital Signals
            </h3>
            <div className="grid sm:grid-cols-2 gap-6">
              {[
                { label: 'Heart Rhythm', val: `${heartRate} BPM`, icon: '❤️', desc: 'Normalized range' },
                { label: 'Stress Index', val: `${data.stressIndex}%`, icon: '🧠', desc: 'Autonomic balance' },
                { label: 'Recovery Level', val: `${data.recoveryLevel}%`, icon: '📈', desc: 'Physiological rebound' },
                { label: 'Energy Score', val: `${data.energyScore}%`, icon: '⚡', desc: 'Metabolic readiness' }
              ].map((m, i) => (
                <div key={i} className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm hover:translate-y-1 transition-all">
                  <div className="flex justify-between items-start mb-6">
                    <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-lg">{m.icon}</div>
                    <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Steady</span>
                  </div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{m.label}</p>
                  <div className="text-3xl font-black text-slate-900 mb-2">{m.val}</div>
                  <p className="text-[10px] text-slate-400 font-bold">{m.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Lifestyle Indicators */}
          <div className="space-y-8">
            <h3 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-4">
              <span className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center text-sm">L</span>
              Lifestyle Indicators
            </h3>
            <div className="grid sm:grid-cols-2 gap-6">
              {[
                { label: 'Fatigue Probability', val: `${fatigueProb}%`, icon: '😴', desc: 'Sleep debt estimate' },
                { label: 'Skin Vitality', val: `${skinVitality}%`, icon: '✨', desc: 'Oxygenation levels' },
                { label: 'Circulation Quality', val: `${circulation}%`, icon: '🌊', desc: 'Pulse wave velocity' },
                { label: 'Biological Age', val: '-2 yrs', icon: '🧬', desc: 'Relative to baseline' }
              ].map((m, i) => (
                <div key={i} className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm hover:translate-y-1 transition-all">
                  <div className="flex justify-between items-start mb-6">
                    <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-lg">{m.icon}</div>
                  </div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{m.label}</p>
                  <div className="text-3xl font-black text-slate-900 mb-2">{m.val}</div>
                  <p className="text-[10px] text-slate-400 font-bold">{m.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Insight & Explanation */}
        <div className="bg-slate-900 rounded-[4rem] p-12 md:p-20 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-blue-600/10 skew-x-12 translate-x-1/4"></div>
          <div className="relative z-10 grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-3 px-4 py-2 bg-white/10 rounded-full border border-white/20">
                <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></span>
                <span className="text-[10px] font-black uppercase tracking-widest">GenAI Wellness Coach</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-black tracking-tight leading-none">
                What this <br /> means for <span className="text-blue-400">you.</span>
              </h2>
              <p className="text-lg text-slate-300 font-medium leading-relaxed opacity-80">
                Our AI coach has synthesized your biomarkers into actionable wellness guidance.
                Focus on these areas to optimize your scores for tomorrow.
              </p>
              <div className="p-6 bg-white/5 rounded-3xl border border-white/10">
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-2 italic">Disclaimer</p>
                <p className="text-[11px] text-slate-400 leading-relaxed font-semibold">
                  Bio-Mirror is a wellness optimization tool. Results are not medical diagnoses.
                  Consult a healthcare professional for clinical concerns.
                </p>
              </div>
            </div>

            <div className="space-y-6">
              {data.advice.map((advice, i) => (
                <div key={i} className="flex gap-8 items-start p-8 bg-white/5 rounded-3xl border border-white/10 hover:bg-white/10 transition-all group">
                  <div className="shrink-0 w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center text-white font-black text-lg">
                    {i + 1}
                  </div>
                  <p className="text-white font-bold text-lg leading-relaxed">
                    {advice}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Navigation / Next Steps */}
        <div className="mt-16 flex flex-col md:flex-row items-center justify-between gap-8 p-12 bg-white rounded-[3rem] border border-slate-100 shadow-sm">
          <div className="space-y-1">
            <h4 className="text-xl font-black text-slate-900">Track Progress</h4>
            <p className="text-sm text-slate-500 font-medium">Add this scan to your history to see weekly trends.</p>
          </div>
          <div className="flex gap-4 w-full md:w-auto">
            <button className="flex-1 md:flex-none px-10 py-5 bg-slate-100 text-slate-900 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-slate-200 transition-all">Discard</button>
            <button
              onClick={onClose}
              className="flex-1 md:flex-none px-10 py-5 bg-blue-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all"
            >
              Save to History
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

function cn(...inputs: any[]) { return inputs.filter(Boolean).join(' '); }
export default ReportPage;
