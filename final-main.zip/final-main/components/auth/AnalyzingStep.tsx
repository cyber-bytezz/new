
import React from 'react';

export const AnalyzingStep: React.FC = () => {
    return (
        <div className="p-20 text-center animate-reveal space-y-16">
            <div className="relative w-48 h-48 mx-auto">
                <div className="absolute inset-0 border-[12px] border-slate-50 rounded-full"></div>
                <div className="absolute inset-0 border-[12px] border-blue-600 rounded-full border-t-transparent animate-spin"></div>
                <div className="absolute inset-10 bg-blue-50/50 rounded-full flex items-center justify-center">
                    <div className="flex flex-col items-center">
                        <span className="text-blue-600 font-black text-2xl">30s</span>
                        <span className="text-[8px] font-black text-blue-400 uppercase tracking-widest leading-none">Processing</span>
                    </div>
                </div>
            </div>
            <div className="space-y-6">
                <div className="space-y-2">
                    <h2 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Analyzing Biomarkers</h2>
                    <p className="text-sm text-slate-400 font-black uppercase tracking-[0.4em] max-w-sm mx-auto leading-relaxed">rPPG Neural Analysis in Progress</p>
                </div>

                <div className="max-w-xs mx-auto space-y-4">
                    {[
                        "Detecting heart rhythm pulse...",
                        "Calculating stress variability...",
                        "Evaluating skin vitality..."
                    ].map((text, i) => (
                        <div key={i} className="flex items-center gap-4 text-left">
                            <div className="w-4 h-4 rounded-full bg-blue-50 flex items-center justify-center">
                                <div className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-pulse"></div>
                            </div>
                            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">{text}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
