
import React, { RefObject } from 'react';

interface ScanStepProps {
    videoRef: RefObject<HTMLVideoElement>;
    onCancel: () => void;
    onCapture: () => void;
}

export const ScanStep: React.FC<ScanStepProps> = ({ videoRef, onCancel, onCapture }) => {
    return (
        <div className="p-8 md:p-10 space-y-8 animate-reveal text-center relative max-w-5xl mx-auto">
            <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-[9px] font-black uppercase tracking-[0.2em] border border-blue-100">
                    Neural Interface Active
                </div>
                <h2 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Position Your Face</h2>
                <p className="text-sm text-slate-400 font-medium max-w-2xl mx-auto">Ensure you are in a well-lit environment for 100% biometric clinical precision.</p>
            </div>

            <div className="relative aspect-video rounded-[3rem] overflow-hidden bg-slate-950 border-[12px] border-slate-50 shadow-[0_40px_80px_-20px_rgba(0,0,0,0.15)] group">
                <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover scale-x-[-1]" />

                {/* Dynamic Scanning Grid overlay */}
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 pointer-events-none"></div>

                {/* Face Guide Overlay - More Premium */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="relative w-[45%] h-[75%] border-2 border-white/20 rounded-[8rem]">
                        {/* Corner brackets */}
                        <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-blue-500 rounded-tl-[2rem]"></div>
                        <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-blue-500 rounded-tr-[2rem]"></div>
                        <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-blue-500 rounded-bl-[2rem]"></div>
                        <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-blue-500 rounded-br-[2rem]"></div>

                        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-4 py-1.5 bg-blue-600 text-white text-[9px] font-black rounded-full uppercase tracking-[0.3em] whitespace-nowrap shadow-xl">
                            Biometric Alignment
                        </div>
                    </div>
                </div>

                {/* Enhanced Signal Indicators */}
                <div className="absolute bottom-6 left-6 right-6 flex justify-center gap-4 pointer-events-none">
                    {[
                        { label: 'Lighting', active: true, value: 'Optimal' },
                        { label: 'Distance', active: true, value: 'Perfect' },
                        { label: 'Stability', active: false, value: 'Hold Still' }
                    ].map((sig, i) => (
                        <div key={i} className="bg-black/60 backdrop-blur-xl px-4 py-3 rounded-2xl border border-white/10 flex items-center gap-3 min-w-[160px]">
                            <div className={`w-2 h-2 rounded-full ${sig.active ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.8)]' : 'bg-white/20'}`}></div>
                            <div className="text-left">
                                <p className="text-[8px] font-black text-white/40 uppercase tracking-widest leading-none mb-1">{sig.label}</p>
                                <p className="text-[10px] font-bold text-white tracking-tight">{sig.value}</p>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Scanning Line Animation */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-blue-400 to-transparent shadow-[0_0_30px_rgba(37,99,235,1)] animate-scan-line blur-[1px]"></div>
            </div>

            <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto">
                <button
                    onClick={onCancel}
                    className="py-5 px-8 bg-slate-100 text-slate-500 rounded-[2rem] font-black text-xs uppercase tracking-[0.4em] hover:bg-slate-200 transition-all font-bold"
                >
                    Abort Scan
                </button>
                <button
                    onClick={onCapture}
                    className="group py-5 px-8 bg-slate-900 text-white rounded-[2rem] font-black text-xs uppercase tracking-[0.4em] hover:bg-blue-600 transition-all shadow-2xl flex items-center justify-center gap-6"
                >
                    Initiate Capture
                    <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg group-hover:rotate-12">
                        <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9 9 0 110-18 9 9 0 010 18z" /><circle cx="12" cy="12" r="3" /></svg>
                    </div>
                </button>
            </div>

            <div className="pt-2">
                <div className="inline-flex items-center gap-3 px-6 py-3 bg-slate-50 rounded-xl border border-slate-100">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                    <p className="text-[10px] text-slate-500 font-bold leading-relaxed">
                        Secure local processing enabled. <span className="text-blue-600">No video data is recorded or uploaded to our servers.</span>
                    </p>
                </div>
            </div>
        </div>
    );
};
