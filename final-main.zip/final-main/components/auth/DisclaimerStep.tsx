
import React from 'react';

interface DisclaimerStepProps {
    agreed: boolean;
    setAgreed: (agreed: boolean) => void;
    onContinue: () => void;
}

export const DisclaimerStep: React.FC<DisclaimerStepProps> = ({ agreed, setAgreed, onContinue }) => {
    return (
        <div className="flex flex-col md:flex-row min-h-[680px] animate-reveal">
            <div className="w-full md:w-5/12 relative bg-slate-900 overflow-hidden">
                <img
                    src="/clinical-safety.png"
                    className="w-full h-full object-cover opacity-60 scale-105 hover:scale-100 transition-transform duration-[4s]"
                    alt="Clinical Environment"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/20 to-transparent"></div>
                <div className="absolute inset-0 bg-blue-600/10 mix-blend-overlay"></div>

                <div className="absolute bottom-16 left-12 right-12 space-y-8">
                    <div className="w-16 h-1 bg-blue-500 rounded-full"></div>
                    <div className="space-y-4">
                        <h3 className="text-4xl font-black text-white leading-tight tracking-tight">Clinical Integrity & <br /><span className="text-blue-400">Privacy Standards</span></h3>
                        <p className="text-slate-300 text-lg font-medium leading-relaxed opacity-80">
                            Your journey through the BioMirror framework is protected by hospital-grade security and ethical data protocols.
                        </p>
                    </div>
                </div>
            </div>

            <div className="flex-1 p-12 md:p-20 bg-white flex flex-col justify-between">
                <div className="space-y-12">
                    <div className="space-y-4">
                        <div className="inline-flex items-center px-4 py-1.5 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-black uppercase tracking-widest border border-blue-100">Safety Protocol</div>
                        <h2 className="text-5xl font-black text-slate-900 tracking-tighter leading-[0.9]">Understand the <br />BioMirror <span className="text-blue-600">Framework</span></h2>
                    </div>

                    <div className="space-y-6">
                        {[
                            { icon: "🛡️", title: "Non-Diagnostic Scope", text: "Results are for wellness optimization, not clinical diagnosis." },
                            { icon: "🔒", title: "Local Synthesis", text: "Your facial metadata is processed locally and discarded instantly." }
                        ].map((item, i) => (
                            <div key={i} className="flex gap-8 items-center p-6 rounded-[2rem] bg-slate-50 border border-slate-100 hover:bg-white hover:border-blue-100 transition-all cursor-default group">
                                <div className="w-14 h-14 rounded-2xl bg-white shadow-sm flex items-center justify-center text-3xl shrink-0 group-hover:scale-110 transition-transform">
                                    {item.icon}
                                </div>
                                <div className="space-y-1">
                                    <h4 className="text-lg font-black text-slate-900 tracking-tight uppercase leading-none mb-1">{item.title}</h4>
                                    <p className="text-sm text-slate-500 font-semibold leading-snug">{item.text}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="pt-12 space-y-8">
                    <label className="flex items-center gap-6 cursor-pointer group px-8 py-6 bg-blue-50/50 rounded-3xl border border-blue-100 hover:bg-blue-600 hover:text-white transition-all shadow-sm">
                        <input
                            type="checkbox"
                            checked={agreed}
                            onChange={(e) => setAgreed(e.target.checked)}
                            className="w-7 h-7 rounded-xl text-blue-600 border-blue-200 focus:ring-blue-500 transition-all cursor-pointer"
                        />
                        <div className="flex flex-col">
                            <span className="text-lg font-black tracking-tight leading-none mb-1 text-inherit">I Accept Clinical Protocols</span>
                            <span className="text-[10px] font-bold opacity-60 uppercase tracking-widest">Digital Signature Required</span>
                        </div>
                    </label>

                    <button
                        disabled={!agreed}
                        onClick={onContinue}
                        className={`group w-full py-6 rounded-[2rem] font-black text-xl flex items-center justify-between px-10 transition-all shadow-[0_25px_50px_-12px_rgba(0,0,0,0.1)] ${agreed ? 'bg-slate-900 text-white hover:bg-slate-800 hover:-translate-y-1' : 'bg-slate-100 text-slate-300 cursor-not-allowed'}`}
                    >
                        <span className="tracking-tight uppercase text-sm font-black tracking-[0.3em]">Initiate Bio-Scan</span>
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${agreed ? 'bg-blue-600' : 'bg-slate-200'} group-hover:translate-x-1`}>
                            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
                        </div>
                    </button>
                </div>
            </div>
        </div>
    );
};
