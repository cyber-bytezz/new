
import React, { useRef, useEffect, useState } from 'react';

const ArchitecturalStack: React.FC = () => {
    const containerRef = useRef<HTMLDivElement>(null);
    const [progress, setProgress] = useState(0);

    useEffect(() => {
        const handleScroll = () => {
            if (!containerRef.current) return;
            const rect = containerRef.current.getBoundingClientRect();
            const windowHeight = window.innerHeight;

            const triggerStart = windowHeight * 0.95;
            const scrollWindow = 80; // slightly longer for the "reveal" transition
            const currentEntry = windowHeight - rect.top;

            const p = Math.max(0, Math.min(1, (currentEntry - triggerStart) / scrollWindow));
            setProgress(p);
        };

        window.addEventListener('scroll', handleScroll, { passive: true });
        window.addEventListener('resize', handleScroll);
        handleScroll();

        return () => {
            window.removeEventListener('scroll', handleScroll);
            window.removeEventListener('resize', handleScroll);
        };
    }, []);

    const layers = [
        {
            id: 'neural',
            title: 'Multimodal Sensing Engine',
            desc: 'High-fidelity signal extraction via multi-wavelength neural analysis.',
            color: 'from-blue-400 via-indigo-500 to-transparent',
            glow: 'rgba(56, 189, 248, 0.4)',
            align: 'left'
        },
        {
            id: 'training',
            title: 'Clinical Intelligence',
            desc: 'Validated by 500k+ samples for medical-grade precision.',
            color: 'from-emerald-400 via-teal-500 to-transparent',
            glow: 'rgba(52, 211, 153, 0.3)',
            align: 'right'
        },
        {
            id: 'processing',
            title: 'Edge Synthesis',
            desc: 'Real-time on-device processing with zero latency.',
            color: 'from-blue-600 via-blue-800 to-transparent',
            glow: 'rgba(37, 99, 235, 0.3)',
            align: 'right'
        },
        {
            id: 'science',
            title: 'Quantum Signal rPPG',
            desc: 'Proprietary rPPG core developed with leading physiological researchers.',
            color: 'from-slate-400 via-slate-600 to-transparent',
            glow: 'rgba(148, 163, 184, 0.3)',
            align: 'left'
        }
    ];

    return (
        <section id="architecture" ref={containerRef} className="relative h-[110vh] bg-[#020617] overflow-hidden flex items-center">
            {/* Blueprint Grid */}
            <div className="absolute inset-0 opacity-10 pointer-events-none"
                style={{
                    backgroundImage: 'radial-gradient(#1e293b 1px, transparent 1px)',
                    backgroundSize: '40px 40px'
                }}>
            </div>

            <div className="sticky top-0 h-screen w-full flex flex-col items-center justify-center overflow-hidden">

                {/* PERSISTENT HEADLINE */}
                <div
                    className="absolute top-12 text-center space-y-2 px-6 z-50 pointer-events-none"
                >
                    <div className="inline-block px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full mb-2">
                        <span className="text-[10px] font-black text-blue-400 uppercase tracking-[0.4em]">Core Architecture</span>
                    </div>
                    <h2 className="text-3xl md:text-5xl font-black text-white tracking-tighter leading-tight">
                        The Neural Foundation of <br />
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-500">Professional Diagnostics</span>
                    </h2>
                </div>

                {/* THE INNOVATIVE STACK */}
                <div className="relative w-full max-w-6xl flex items-center justify-center scale-90 md:scale-100" style={{ perspective: '3000px' }}>

                    {/* CENTER RAYS - Project upwards from the closed stack */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full pointer-events-none z-40 transition-opacity duration-500"
                        style={{ opacity: 1 - progress }}>
                        {/* Technical Beam Ray 1 */}
                        <div className="absolute top-[45%] left-1/2 -translate-x-1/2 w-[2px] h-[300px] bg-gradient-to-t from-blue-500 to-transparent blur-[1px] origin-bottom -rotate-[20deg]"></div>
                        {/* Technical Beam Ray 2 */}
                        <div className="absolute top-[45%] left-1/2 -translate-x-1/2 w-[2px] h-[300px] bg-gradient-to-t from-blue-400 to-transparent blur-[1px] origin-bottom rotate-[25deg]"></div>
                        {/* Core Flare */}
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-blue-500/20 blur-[60px] rounded-full"></div>
                    </div>

                    <div
                        className="relative transition-transform duration-700 ease-out"
                        style={{
                            transformStyle: 'preserve-3d',
                            transform: `rotateX(${65 - progress * 5}deg) rotateZ(${-35 - progress * 10}deg) scale(${0.8 + progress * 0.2})`
                        }}
                    >
                        {layers.map((layer, idx) => {
                            const offset = (idx - (layers.length - 1) / 2) * progress * 190;
                            const zIndex = layers.length - idx;

                            return (
                                <div
                                    key={layer.id}
                                    className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 md:w-[480px] md:h-[480px] transition-all duration-300"
                                    style={{
                                        transform: `translate(-50%, -50%) translateY(${offset}px)`,
                                        zIndex: zIndex,
                                    }}
                                >
                                    <div className="relative w-full h-full group">
                                        {/* Board Body */}
                                        <div className={`w-full h-full rounded-[2.5rem] bg-gradient-to-br ${layer.color} backdrop-blur-md shadow-2xl border border-white/10 overflow-hidden relative transition-all duration-500`}
                                            style={{
                                                boxShadow: `0 0 ${40 + progress * 40}px ${layer.glow}`,
                                                clipPath: 'polygon(10% 0%, 90% 0%, 100% 10%, 100% 90%, 90% 100%, 10% 100%, 0% 90%, 0% 10%)'
                                            }}>

                                            <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>

                                            {/* CENTRAL "BIOMIRROR CORE" LOGO - Visible when closed, fades as it unfolds */}
                                            {idx === 0 && (
                                                <div className="absolute inset-0 flex flex-col items-center justify-center transition-all duration-700"
                                                    style={{
                                                        opacity: 1 - progress * 1.5,
                                                        transform: `scale(${1 + progress * 0.5})`
                                                    }}>
                                                    <div className="w-16 h-16 border-2 border-white/40 rounded-full mb-4 animate-[spin_10s_linear_infinite] flex items-center justify-center">
                                                        <div className="w-12 h-12 border-t-2 border-blue-400 rounded-full"></div>
                                                    </div>
                                                    <span className="text-white font-black text-2xl md:text-3xl tracking-tighter uppercase italic px-4 py-2 bg-black/40 backdrop-blur-md border-y border-white/10">BIOMIRROR CORE</span>
                                                    <span className="text-[10px] font-mono text-blue-400 mt-2 font-black uppercase tracking-[0.4em] animate-pulse">Establishing Signal...</span>
                                                </div>
                                            )}

                                            {/* TECHNICAL DETAILS - Visible when unfolded */}
                                            <div className="absolute inset-0 flex items-center justify-center transition-opacity duration-1000"
                                                style={{ opacity: progress }}>
                                                <span className="text-white/10 font-black text-xl italic tracking-tighter uppercase">BIOMIRROR_CORE_{idx}</span>
                                            </div>

                                            <div className="absolute top-4 left-4 text-[8px] font-mono text-white/50">NODE_0{idx} // ARCH_v2.0</div>
                                            <div className="absolute bottom-4 right-4 text-[8px] font-mono text-white/50 italic">{60 + Math.floor(progress * 40)}% ENGINE_LOAD</div>
                                        </div>

                                        {/* LABELS - STRONG VISIBILITY */}
                                        <div
                                            className={`absolute top-1/2 w-[320px] md:w-[480px] flex items-center transition-all duration-500
                                                ${layer.align === 'left' ? '-left-[280px] md:-left-[440px] flex-row-reverse text-right' : '-right-[280px] md:-right-[440px] text-left'}
                                            `}
                                            style={{
                                                opacity: Math.max(0, (progress - 0.1) * 15),
                                                visibility: progress > 0.05 ? 'visible' : 'hidden',
                                                transform: `translateY(${layer.align === 'left' ? -15 : 15}px)`
                                            }}
                                        >
                                            <div className="relative flex-grow h-[2px] bg-gradient-to-r from-blue-400/80 to-transparent">
                                                <div className={`absolute top-0 w-3 h-3 rounded-full bg-blue-300 shadow-[0_0_15px_#60a5fa] ${layer.align === 'left' ? 'right-0' : 'left-0'}`}></div>
                                            </div>

                                            <div className="w-60 md:w-80 px-5 space-y-1">
                                                <div className="flex items-baseline gap-2">
                                                    <span className="text-[12px] font-mono text-blue-300 font-black">X_SENSE_0{idx + 1}</span>
                                                    <h4 className="text-white font-black text-base md:text-lg tracking-tight uppercase leading-none">
                                                        {layer.title}
                                                    </h4>
                                                </div>
                                                <div className="border-l-2 border-blue-400/60 pl-3 ml-6">
                                                    <p className="text-slate-100 text-[10.5px] md:text-[13px] font-extrabold leading-relaxed">
                                                        {layer.desc}
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* Vertical Data Streams */}
                <div className="absolute inset-0 pointer-events-none z-20">
                    {[...Array(6)].map((_, i) => (
                        <div
                            key={i}
                            className="absolute bg-blue-400/20 w-px h-64 blur-[1px]"
                            style={{
                                left: `${15 + i * 14}%`,
                                top: `${-20 + i * 20}%`,
                                opacity: progress * 0.4,
                                transform: `translateY(${progress * 250}px)`
                            }}
                        ></div>
                    ))}
                </div>

            </div>
        </section>
    );
};

export default ArchitecturalStack;
