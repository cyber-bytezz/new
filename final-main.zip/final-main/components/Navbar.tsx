
import React from 'react';

interface NavbarProps {
  onSignInClick: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onSignInClick }) => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/70 backdrop-blur-xl border-b border-slate-100 px-8 py-5">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3 group cursor-pointer">
          <div className="w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center shadow-xl shadow-blue-200 group-hover:rotate-12 transition-transform duration-500">
            <div className="w-4 h-4 bg-white rounded-full"></div>
          </div>
          <span className="text-2xl font-black text-slate-900 tracking-tighter">BioMirror</span>
        </div>
        
        <div className="hidden lg:flex items-center space-x-12">
          {['Solutions', 'Methodology', 'Our Team', 'Trust', 'Connect'].map((item) => (
            <a key={item} href="#" className="text-[11px] font-black text-slate-400 hover:text-blue-600 transition-colors uppercase tracking-[0.2em]">
              {item}
            </a>
          ))}
        </div>
        
        <div className="flex items-center gap-4">
          <button className="hidden sm:block px-6 py-3 text-[11px] font-black text-slate-400 hover:text-slate-900 transition-colors uppercase tracking-[0.2em]">
            Patient Portal
          </button>
          <button 
            onClick={onSignInClick}
            className="px-8 py-3.5 bg-blue-600 text-white rounded-2xl text-[11px] font-black shadow-2xl shadow-blue-200 hover:bg-slate-900 transition-all uppercase tracking-[0.2em] flex items-center gap-3"
          >
            Sign In
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" /></svg>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
