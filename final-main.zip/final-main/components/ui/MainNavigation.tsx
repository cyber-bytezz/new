
'use client';
import React from 'react';
import { Button, buttonVariants } from './button';
import { cn } from '../../lib/utils';
import { MenuToggleIcon } from './menu-toggle-icon';
import { useScroll } from './use-scroll';

interface MainNavigationProps {
  onSignInClick: () => void;
}

export function MainNavigation({ onSignInClick }: MainNavigationProps) {
	const [open, setOpen] = React.useState(false);
	const scrolled = useScroll(10);

	const links = [
		{ label: 'Solutions', href: '#' },
		{ label: 'Methodology', href: '#' },
		{ label: 'Our Team', href: '#' },
		{ label: 'Trust', href: '#' },
		{ label: 'Connect', href: '#' },
	];

	React.useEffect(() => {
		if (open) {
			document.body.style.overflow = 'hidden';
		} else {
			document.body.style.overflow = '';
		}

		return () => {
			document.body.style.overflow = '';
		};
	}, [open]);

	return (
		<header
			className={cn(
				'fixed top-0 z-50 mx-auto w-full max-w-full border-b border-transparent transition-all ease-out',
				{
					'bg-white/80 supports-[backdrop-filter]:bg-white/50 border-slate-200/50 backdrop-blur-lg md:top-4 md:max-w-7xl md:rounded-[1.5rem] md:shadow-2xl md:shadow-blue-500/5 left-1/2 -translate-x-1/2':
						scrolled && !open,
					'bg-white': open,
				},
			)}
		>
			<nav
				className={cn(
					'flex h-16 w-full items-center justify-between px-6 md:h-20 transition-all ease-out max-w-7xl mx-auto',
					{
						'md:h-16': scrolled,
					},
				)}
			>
				<div className="flex items-center space-x-3 group cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
          <div className="w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center shadow-xl shadow-blue-200 group-hover:rotate-12 transition-transform duration-500">
            <div className="w-4 h-4 bg-white rounded-full"></div>
          </div>
          <span className="text-2xl font-black text-slate-900 tracking-tighter">BioMirror</span>
        </div>

				<div className="hidden items-center gap-2 lg:flex">
					{links.map((link, i) => (
						<a 
              key={i} 
              className={buttonVariants({ variant: 'ghost', className: 'text-[11px] font-black uppercase tracking-[0.2em] text-slate-400 hover:text-blue-600' })} 
              href={link.href}
            >
							{link.label}
						</a>
					))}
					<div className="w-px h-6 bg-slate-100 mx-4" />
					<Button 
            variant="ghost" 
            className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-400"
            onClick={onSignInClick}
          >
            Portal
          </Button>
					<Button 
            className="rounded-xl px-8 py-6 bg-blue-600 text-white text-[11px] font-black uppercase tracking-[0.2em] shadow-xl shadow-blue-100 hover:bg-slate-900 transition-all"
            onClick={onSignInClick}
          >
            Get Started
          </Button>
				</div>
				<Button size="icon" variant="ghost" onClick={() => setOpen(!open)} className="lg:hidden">
					<MenuToggleIcon open={open} className="size-6 text-slate-900" duration={300} />
				</Button>
			</nav>

			<div
				className={cn(
					'bg-white fixed top-16 right-0 bottom-0 left-0 z-50 flex flex-col overflow-hidden border-y lg:hidden',
					open ? 'block' : 'hidden',
				)}
			>
				<div
					data-slot={open ? 'open' : 'closed'}
					className={cn(
						'data-[slot=open]:animate-in data-[slot=open]:zoom-in-95 data-[slot=closed]:animate-out data-[slot=closed]:zoom-out-95 ease-out',
						'flex h-full w-full flex-col justify-between gap-y-2 p-6',
					)}
				>
					<div className="grid gap-y-2">
						{links.map((link) => (
							<a
								key={link.label}
								className={buttonVariants({
									variant: 'ghost',
									className: 'justify-start text-lg font-bold py-8',
								})}
								href={link.href}
							>
								{link.label}
							</a>
						))}
					</div>
					<div className="flex flex-col gap-4 mb-20">
						<Button variant="outline" className="w-full py-8 text-lg font-bold rounded-2xl" onClick={() => {setOpen(false); onSignInClick();}}>
							Portal Access
						</Button>
						<Button className="w-full py-8 text-lg font-bold rounded-2xl bg-blue-600 shadow-xl" onClick={() => {setOpen(false); onSignInClick();}}>
							Get Started Now
						</Button>
					</div>
				</div>
			</div>
		</header>
	);
}
