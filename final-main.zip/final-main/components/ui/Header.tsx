
'use client';
import React from 'react';
import { Button, buttonVariants } from './button';
import { cn } from '../../lib/utils';
import { MenuToggleIcon } from './menu-toggle-icon';
import { useScroll } from './use-scroll';

export type HeaderMode = 'landing' | 'portal' | 'report';

interface HeaderProps {
	onSignInClick?: () => void;
	onExitClick?: () => void;
	mode?: HeaderMode;
	customActions?: React.ReactNode;
}

export function Header({
	onSignInClick,
	onExitClick,
	mode = 'landing',
	customActions
}: HeaderProps) {
	const [open, setOpen] = React.useState(false);
	const scrolled = useScroll(10);

	const links = mode === 'landing' ? [
		{ label: 'Features', href: '#features' },
		{ label: 'Methodology', href: '#methodology' },
		{ label: 'Performance', href: '#trends' },
		{ label: 'Trust', href: '#privacy' },
		{ label: 'Solutions', href: '#enterprise' },
	] : [];

	const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
		if (href.startsWith('#')) {
			e.preventDefault();
			const targetId = href.replace('#', '');
			const element = document.getElementById(targetId);
			if (element) {
				setOpen(false);
				const headerOffset = 100;
				const elementPosition = element.getBoundingClientRect().top;
				const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

				window.scrollTo({
					top: offsetPosition,
					behavior: 'smooth'
				});
			}
		}
	};

	React.useEffect(() => {
		if (open) {
			document.body.style.overflow = 'hidden';
		} else {
			document.body.style.overflow = '';
		}
		return () => {
			document.body.style.overflow = '';
		};
	}, [open]);

	return (
		<header
			className={cn(
				'sticky top-0 z-50 mx-auto w-full max-w-full border-b border-transparent transition-all duration-500 ease-out',
				{
					'bg-white/80 supports-[backdrop-filter]:bg-white/50 border-slate-200/50 backdrop-blur-xl md:top-4 md:max-w-7xl md:rounded-2xl md:border md:shadow-2xl md:shadow-blue-500/10':
						(scrolled || mode !== 'landing') && !open,
					'bg-white h-screen md:h-auto': open,
				},
			)}
		>
			<nav
				className={cn(
					'flex h-16 w-full items-center justify-between px-6 md:h-14 md:transition-all md:ease-out',
					{
						'md:px-8': scrolled,
					},
				)}
			>
				<div
					className="flex items-center gap-3 cursor-pointer group"
					onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
				>
					<div className="w-8 h-8 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200 group-hover:rotate-12 transition-transform duration-300">
						<div className="w-3 h-3 bg-white rounded-full"></div>
					</div>
					<span className="text-xl font-black text-slate-900 tracking-tighter">
						BioMirror
						{mode !== 'landing' && <span className="text-blue-600 font-bold ml-2 text-sm tracking-widest uppercase">{mode}</span>}
					</span>
				</div>

				<div className="hidden items-center gap-2 md:flex">
					{links.map((link, i) => (
						<a
							key={i}
							className={buttonVariants({ variant: 'ghost', className: 'text-[11px] font-black uppercase tracking-widest text-slate-400 hover:text-blue-600' })}
							href={link.href}
							onClick={(e) => handleLinkClick(e, link.href)}
						>
							{link.label}
						</a>
					))}

					{mode === 'landing' ? (
						<>
							{/* <Button
								variant="outline"
								className="rounded-xl border-slate-200 text-xs font-bold ml-4"
								onClick={onSignInClick}
							>
								Portal
							</Button> */}
							<Button
								className="rounded-xl bg-blue-600 text-white shadow-lg shadow-blue-100 text-xs font-bold hover:bg-slate-900 transition-all"
								onClick={onSignInClick}
							>
								Get Started
							</Button>
						</>
					) : (
						<div className="flex items-center gap-4 ml-4">
							{customActions}
							<Button
								variant="outline"
								className="rounded-xl border-slate-200 text-xs font-bold flex items-center gap-2 group/btn"
								onClick={onExitClick}
							>
								<svg className="w-3.5 h-3.5 group-hover/btn:-translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
								Exit {mode === 'portal' ? 'Portal' : 'Report'}
							</Button>
						</div>
					)}
				</div>
				<Button size="icon" variant="ghost" onClick={() => setOpen(!open)} className="md:hidden">
					<MenuToggleIcon open={open} className="size-6 text-slate-900" duration={300} />
				</Button>
			</nav>

			<div
				className={cn(
					'bg-white fixed top-16 right-0 bottom-0 left-0 z-50 flex flex-col overflow-hidden border-y md:hidden transition-all duration-300',
					open ? 'translate-y-0 opacity-100 visible' : '-translate-y-4 opacity-0 invisible',
				)}
			>
				<div
					data-slot={open ? 'open' : 'closed'}
					className={cn(
						'data-[slot=open]:animate-in data-[slot=open]:zoom-in-95 data-[slot=closed]:animate-out data-[slot=closed]:zoom-out-95 ease-out',
						'flex h-full w-full flex-col justify-between gap-y-2 p-6 pb-24',
					)}
				>
					<div className="grid gap-y-4 pt-10">
						{links.map((link) => (
							<a
								key={link.label}
								className={buttonVariants({
									variant: 'ghost',
									className: 'justify-start text-2xl font-black py-8',
								})}
								href={link.href}
								onClick={(e) => handleLinkClick(e, link.href)}
							>
								{link.label}
							</a>
						))}
					</div>
					<div className="flex flex-col gap-4">
						{mode === 'landing' ? (
							<>
								<Button
									variant="outline"
									className="w-full py-8 text-lg font-bold rounded-2xl border-2"
									onClick={() => { setOpen(false); onSignInClick?.(); }}
								>
									Patient Portal
								</Button>
								<Button
									className="w-full py-8 text-lg font-bold rounded-2xl bg-blue-600 shadow-xl"
									onClick={() => { setOpen(false); onSignInClick?.(); }}
								>
									Get Started Now
								</Button>
							</>
						) : (
							<Button
								variant="outline"
								className="w-full py-8 text-lg font-bold rounded-2xl border-2"
								onClick={() => { setOpen(false); onExitClick?.(); }}
							>
								Exit {mode}
							</Button>
						)}
					</div>
				</div>
			</div>
		</header>
	);
}
