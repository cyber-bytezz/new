
import React from 'react';
import { MetricData, Insight, TrendData } from './types';

export const METRICS: MetricData[] = [
  { label: 'Overall Wellness', value: 78, unit: '/ 100', status: 'optimal', color: 'bg-emerald-500' },
  { label: 'Stress Index', value: 24, unit: '%', status: 'good', color: 'bg-amber-400' },
  { label: 'Energy Score', value: 82, unit: '', status: 'optimal', color: 'bg-emerald-400' },
  { label: 'Recovery Level', value: 65, unit: '%', status: 'average', color: 'bg-sky-400' },
  { label: 'Skin Vitality', value: 91, unit: '%', status: 'optimal', color: 'bg-emerald-500' },
  { label: 'Circulation', value: 88, unit: '', status: 'optimal', color: 'bg-emerald-400' },
];

export const INSIGHTS: Insight[] = [
  {
    id: '1',
    title: 'Focus on Balance',
    description: 'Stress indicators may be slightly higher than usual today. A short breathing exercise could help reset your focus.',
    type: 'stress'
  },
  {
    id: '2',
    title: 'Hydration Peak',
    description: 'Your skin vitality looks excellent. Keep up the hydration routine to maintain this natural glow.',
    type: 'habit'
  },
  {
    id: '3',
    title: 'Recovery Insight',
    description: 'Energy levels are building. You might feel more productive in the late afternoon today.',
    type: 'energy'
  }
];

export const TREND_DATA: TrendData[] = [
  { day: 'Mon', energy: 65, stress: 40 },
  { day: 'Tue', energy: 72, stress: 35 },
  { day: 'Wed', energy: 85, stress: 25 },
  { day: 'Thu', energy: 78, stress: 30 },
  { day: 'Fri', energy: 90, stress: 20 },
  { day: 'Sat', energy: 82, stress: 15 },
  { day: 'Sun', energy: 88, stress: 18 },
];

export const ICONS = {
  Scan: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
    </svg>
  ),
  Camera: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  ),
  Brain: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
    </svg>
  ),
  Shield: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
  )
};
